// Función para generar una fecha aleatoria entre hoy y 30 días atrás
function generarFechaAleatoria() {
    const hoy = new Date();
    const diasAleatorios = Math.floor(Math.random() * 30); // 0 a 29 días
    hoy.setDate(hoy.getDate() - diasAleatorios);
    return hoy.toISOString().split('T')[0]; // Formato: YYYY-MM-DD
}

// Función para seleccionar un estado aleatorio basado en la ruta real
function generarEstadoAleatorio() {
    const estados = [
        "En ruta desde China",
        "En aduana de Manzanillo",
        "En proceso aduanal",
        "En tránsito local",
        "En ruta de entrega",
        "Entregado"
    ];
    return estados[Math.floor(Math.random() * estados.length)];
}

// Función para generar la ubicación correspondiente al estado
function generarUbicacion(estado) {
    switch (estado) {
        case "En ruta desde China":
            return "Océano Pacífico";
        case "En aduana de Manzanillo":
            return "Aduana de Manzanillo, Colima, México";
        case "En proceso aduanal":
            return "Aduana de Manzanillo, Colima, México";
        case "En tránsito local":
            return "Centro de Distribución Local";
        case "En ruta de entrega":
            return "En camino al domicilio del cliente";
        case "Entregado":
            return "Domicilio del cliente";
        default:
            return "Ubicación desconocida";
    }
}

// Generar la "base de datos" de pedidos
const pedidos = {};

for (let i = 10000; i <= 99999; i++) {
    const estado = generarEstadoAleatorio();
    pedidos[i] = {
        estado: estado,
        ubicacion: generarUbicacion(estado),
        fechaPedido: generarFechaAleatoria()
    };
}

document.getElementById("tracking-form").addEventListener("submit", function(event) {
    event.preventDefault(); // Prevenir que la página se recargue al enviar el formulario
    const trackingNumber = document.getElementById("tracking-number").value; // Obtener el número de rastreo ingresado
    const resultDiv = document.getElementById("result"); // Div donde se mostrará el resultado

    if (pedidos[trackingNumber]) { // Verificar si el número de rastreo existe en nuestra "base de datos"
        const pedido = pedidos[trackingNumber];
        const fechaPedido = new Date(pedido.fechaPedido);
        const fechaEntregaMin = new Date(fechaPedido);
        const fechaEntregaMax = new Date(fechaPedido);

        // Calcular la fecha estimada de entrega (15 a 20 días después del pedido)
        fechaEntregaMin.setDate(fechaPedido.getDate() + 15);
        fechaEntregaMax.setDate(fechaPedido.getDate() + 20);

        resultDiv.innerHTML = `<p>Estado: <strong>${pedido.estado}</strong></p>
                               <p>Última ubicación: <strong>${pedido.ubicacion}</strong></p>
                               <p>Fecha estimada de entrega: <strong>${fechaEntregaMin.toLocaleDateString()} - ${fechaEntregaMax.toLocaleDateString()}</strong></p>`;
    } else {
        resultDiv.textContent = "Número de rastreo no encontrado."; // Mensaje de error si no se encuentra el número
    }
});
document.addEventListener('DOMContentLoaded', () => {
    console.log('El contenido del DOM está cargado y listo');
});
